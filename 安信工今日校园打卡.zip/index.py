﻿import DailyCP

def main_handler(event, context):
    user="学号"
    password="密码"
    address="定位地址"
    Qmsgid="接口秘钥"   #Qmsg酱id(选填) 注册地址https://qmsg.zendee.cn/
    QQ=""                            #Qmsg酱上登记的QQ号(选填)
    latitude=33.246907              #纬度(经纬度不影响定位显示，但不可设为0.0，会导致定位失败)
    longitude=117.382841              #经度
    
    DailyCP.main(user,password,address,latitude,longitude,Qmsgid,QQ)
